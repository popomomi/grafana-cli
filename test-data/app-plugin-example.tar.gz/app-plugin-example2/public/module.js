define([
], function()  {

  console.log('app-plugin-init');

});
